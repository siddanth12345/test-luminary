# The Luminary 3D (Enhanced)

Smash-style 3D arena fighter (Three.js) with character select, custom bot characters, and improved mobile controls.

## New in this build
- **Character select** (start screen → Characters)
  - 8 fighters with descriptions, playstyle, walk speed, melee notes, specials
  - Preview panel on the right
  - Your choice is used in normal modes (Easy / Medium / Hard / Training / Online 1v1)
- **Custom match**
  - Choose CPU character when adding bots
  - Bot rows show the chosen fighter
- **Separate Grab button** on mobile (drag to aim, snaps back). Shield no longer drags for grab.
- Starting foundation for items, charge melees, timer mode, save presets (next iteration)

## Characters
1. **The Luminary** (default) – balanced, Core orb specials  
2. **Vesper** – light/fast, Shadow Step  
3. **Titan** – tank/slow, Fortress  
4. **Nyx** – balanced, Lunar Bind freeze  
5. **Bolt** – very fast, Overcharge  
6. **Grove** – medium, Bloom seed  
7. **Rook** – tank, Bastion wall  
8. **Ember** – glass cannon, Ignite stacks  

## Run locally
```bash
python3 -m http.server 8080
# open http://localhost:8080
```

## Deploy
Push to GitHub → enable Pages on the `main` branch →  
`https://YOURUSER.github.io/REPO/`

Original base: https://siddanth12345.github.io/luminary/
