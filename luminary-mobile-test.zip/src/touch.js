// Mobile controls. Left half = dynamic joystick. Right side = aim grid
// (red centre + four black buttons), Jump, Shield, and a SEPARATE Grab button.
// Grab is drag-to-aim and snaps back on release. Shield no longer drags for grab.

import { S, mouse, fighters, p1 } from './core.js';
import { virtual } from './controls.js';
import { getLayout, touchMode, onLayout } from './layout.js';

export const MATRIX_BASE = 230;
export const matrixSize = () => Math.max(150, Math.min(MATRIX_BASE, Math.min(window.innerWidth, window.innerHeight) * 0.56));

const DIRS = { UP: [0, -1], DOWN: [0, 1], SIDE_LEFT: [-1, 0], SIDE_RIGHT: [1, 0] };
const HOLD_MS = 400;

export function buildControls(host) {
    host.insertAdjacentHTML('beforeend', `
        <div class="tz-matrix" data-k="matrix">
            <div class="tz-ring"></div>
            <button class="tz-b tz-dir" data-dir="UP" aria-label="Up attack">↑</button>
            <button class="tz-b tz-dir" data-dir="SIDE_LEFT" aria-label="Left attack">←</button>
            <button class="tz-b tz-dir" data-dir="SIDE_RIGHT" aria-label="Right attack">→</button>
            <button class="tz-b tz-dir" data-dir="DOWN" aria-label="Down attack">↓</button>
            <button class="tz-b tz-main" data-main aria-label="Neutral attack">J<small>hold F</small></button>
        </div>
        <button class="tz-b tz-round tz-jump" data-k="jump">JUMP</button>
        <button class="tz-b tz-round tz-shield" data-k="shield">SHIELD</button>
        <button class="tz-b tz-round tz-grab" data-k="grab">GRAB</button>`);
    const q = (s) => host.querySelector(s);
    return { matrix: q('[data-k="matrix"]'), jump: q('[data-k="jump"]'), shield: q('[data-k="shield"]'), grab: q('[data-k="grab"]'), host };
}

export function positionControls(refs, cfg, w = window.innerWidth, h = window.innerHeight) {
    const M = matrixSize();
    const place = (el, c, size) => {
        if (!el || !c) return;
        el.style.width = el.style.height = size + 'px';
        const x = Math.min(w - size / 2, Math.max(size / 2, c.x * w)), y = Math.min(h - size / 2, Math.max(size / 2, c.y * h));
        el.style.left = (x - size / 2) + 'px'; el.style.top = (y - size / 2) + 'px';
    };
    place(refs.matrix, cfg.matrix, M);
    for (const k of ['jump', 'shield', 'grab']) {
        const c = cfg[k] || (k === 'grab' ? { x: 0.82, y: 0.72, s: 70 } : null);
        if (c) place(refs[k], c, c.s || 70);
    }
    const sub = refs.matrix, d = M * 0.22, off = M * 0.31, c = M / 2;
    const put = (el, dx, dy, dd) => { el.style.width = el.style.height = dd + 'px'; el.style.left = (c + dx - dd / 2) + 'px'; el.style.top = (c + dy - dd / 2) + 'px'; };
    for (const b of sub.querySelectorAll('.tz-dir')) { const v = DIRS[b.dataset.dir]; put(b, v[0] * off, v[1] * off, d); }
    put(sub.querySelector('.tz-main'), 0, 0, M * 0.26);
    return { M, off, d };
}

export class TouchControls {
    constructor({ root, doAction, releaseAction, cancelF, heldChanged }) {
        this.api = { doAction, releaseAction, cancelF, heldChanged };
        this.on = false;
        this.hud = document.createElement('div');
        this.hud.className = 'tz-hud';
        this.hud.style.display = 'none';
        this.hud.innerHTML = `<div class="tz-zone" data-zone></div><div class="tz-joybase" data-base><i data-stick></i></div>`;
        root.appendChild(this.hud);
        this.refs = buildControls(this.hud);
        this.zone = this.hud.querySelector('[data-zone]');
        this.base = this.hud.querySelector('[data-base]');
        this.stick = this.hud.querySelector('[data-stick]');
        this.joy = null; this.joyVec = null; this.dirX = 0;
        this.geo = null;
        this.wire();
        const apply = () => this.apply();
        window.addEventListener('resize', apply);
        onLayout(apply);
        this.apply();
    }

    me() { return S.match ? (fighters[S.mySlot || 0] || p1) : p1; }

    apply() {
        const active = touchMode();
        if (active !== this.on) {
            this.on = active;
            mouse.touchMode = active;
            document.body.classList.toggle('touch-ui', active);
            if (!active) this.releaseAll();
        }
        this.geo = positionControls(this.refs, getLayout().mobile);
    }

    tick() {
        const show = this.on && (S.gameState === 'playing' || S.gameState === 'countdown');
        this.hud.style.display = show ? 'block' : 'none';
        if (!show && (this.joy || virtual.shield)) this.releaseAll();
        if (this.on) { const m = this.me(); if (!this.pressedAim) { mouse.worldX = m.x + this.facingVec(m)[0] * 400; mouse.worldY = m.y + this.facingVec(m)[1] * 400; } }
    }

    releaseAll() {
        this.joy = null; this.joyVec = null; this.base.style.display = 'none';
        virtual.left = virtual.right = virtual.shield = virtual.drop = false;
        this.api.heldChanged();
    }

    facingVec(m) { return this.joyVec ? this.joyVec : [m.facing || 1, 0]; }
    setAim(dir, vec) {
        const m = this.me();
        let v = vec;
        if (!v) v = dir && DIRS[dir] ? DIRS[dir] : this.facingVec(m);
        mouse.direction = dir || 'NEUTRAL';
        mouse.worldX = m.x + v[0] * 500; mouse.worldY = m.y + v[1] * 500;
    }
    act(name, dir, vec) { this.pressedAim = true; this.setAim(dir, vec); this.api.doAction(name); this.pressedAim = false; }

    wire() {
        const R = 58;
        const z = this.zone;
        z.addEventListener('pointerdown', (e) => {
            if (this.joy) return;
            e.preventDefault(); z.setPointerCapture(e.pointerId);
            this.joy = { id: e.pointerId, ox: e.clientX, oy: e.clientY };
            this.base.style.display = 'block';
            this.base.style.left = e.clientX + 'px'; this.base.style.top = e.clientY + 'px';
            this.stick.style.transform = 'translate(-50%,-50%)';
        });
        z.addEventListener('pointermove', (e) => {
            if (!this.joy || e.pointerId !== this.joy.id) return;
            let dx = e.clientX - this.joy.ox, dy = e.clientY - this.joy.oy;
            const len = Math.hypot(dx, dy);
            if (len > R) { this.joy.ox += dx - dx * R / len; this.joy.oy += dy - dy * R / len; dx = dx * R / len; dy = dy * R / len; }
            this.base.style.left = this.joy.ox + 'px'; this.base.style.top = this.joy.oy + 'px';
            this.stick.style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`;
            const mag = Math.hypot(dx, dy);
            this.joyVec = mag > 14 ? [dx / mag, dy / mag] : null;
            const dirX = dx < -16 ? -1 : dx > 16 ? 1 : 0;
            if (virtual.shield) {
                if (dirX && dirX !== this.dirX) { const m = this.me(); this.pressedAim = true; mouse.worldX = m.x + dirX * 300; mouse.worldY = m.y; this.api.doAction('roll'); this.pressedAim = false; }
                virtual.left = virtual.right = false;
            } else { virtual.left = dirX < 0; virtual.right = dirX > 0; }
            this.dirX = dirX;
            virtual.drop = dy > 46;
            this.api.heldChanged();
        });
        const joyEnd = (e) => {
            if (!this.joy || e.pointerId !== this.joy.id) return;
            this.joy = null; this.joyVec = null; this.dirX = 0; this.base.style.display = 'none';
            virtual.left = virtual.right = virtual.drop = false; this.api.heldChanged();
        };
        z.addEventListener('pointerup', joyEnd); z.addEventListener('pointercancel', joyEnd);

        for (const b of this.refs.matrix.querySelectorAll('.tz-dir')) {
            b.addEventListener('pointerdown', (e) => { e.preventDefault(); e.stopPropagation(); b.classList.add('down'); this.act('attack', b.dataset.dir); });
            const up = () => b.classList.remove('down');
            b.addEventListener('pointerup', up); b.addEventListener('pointercancel', up); b.addEventListener('pointerleave', up);
        }

        const main = this.refs.matrix.querySelector('.tz-main');
        let g = null;
        const dirButton = (d) => this.refs.matrix.querySelector(`.tz-dir[data-dir="${d}"]`);
        const clearSel = () => { for (const b of this.refs.matrix.querySelectorAll('.tz-dir')) b.classList.remove('sel'); };
        main.addEventListener('pointerdown', (e) => {
            if (g) return;
            e.preventDefault(); e.stopPropagation(); main.setPointerCapture(e.pointerId);
            g = { id: e.pointerId, sx: e.clientX, sy: e.clientY, sel: null, charging: false, timer: 0 };
            main.classList.add('down');
            g.timer = setTimeout(() => {
                if (!g || g.sel) return;
                g.charging = true; main.classList.add('charging');
                this.pressedAim = true; this.setAim('NEUTRAL'); this.api.doAction('special'); this.pressedAim = false;
            }, HOLD_MS);
        });
        main.addEventListener('pointermove', (e) => {
            if (!g || e.pointerId !== g.id) return;
            const dx = e.clientX - g.sx, dy = e.clientY - g.sy;
            const len = Math.hypot(dx, dy);
            let sel = null;
            if (len > 36) {
                if (Math.abs(dx) > Math.abs(dy)) sel = dx < 0 ? 'SIDE_LEFT' : 'SIDE_RIGHT';
                else sel = dy < 0 ? 'UP' : 'DOWN';
            }
            if (sel !== g.sel) {
                clearSel();
                g.sel = sel;
                if (sel) { const btn = dirButton(sel); if (btn) btn.classList.add('sel'); }
                if (g.charging && sel) { this.api.cancelF(); g.charging = false; main.classList.remove('charging'); clearTimeout(g.timer); }
            }
            // reduced movement so Safari does not interpret as fullscreen gesture
            const k = len > 40 ? 40 / len : 1;
            main.style.transform = `translate(${dx * k * 0.35}px, ${dy * k * 0.35}px)`;
        });
        const mainEnd = (e) => {
            if (!g || e.pointerId !== g.id) return;
            const s = g; g = null;
            clearTimeout(s.timer);
            main.classList.remove('down', 'charging'); main.style.transform = ''; clearSel();
            if (e.type === 'pointercancel') { if (s.charging) this.api.cancelF(); return; }
            if (s.sel) { this.act('special', s.sel); this.api.releaseAction('special'); }
            else if (s.charging) { this.pressedAim = true; this.setAim('NEUTRAL'); this.api.releaseAction('special'); this.pressedAim = false; }
            else this.act('attack', 'NEUTRAL');
        };
        main.addEventListener('pointerup', mainEnd); main.addEventListener('pointercancel', mainEnd);

        this.refs.jump.addEventListener('pointerdown', (e) => { e.preventDefault(); e.stopPropagation(); this.refs.jump.classList.add('down'); this.act('jump'); });
        const unj = () => this.refs.jump.classList.remove('down');
        this.refs.jump.addEventListener('pointerup', unj); this.refs.jump.addEventListener('pointercancel', unj);

        // SHIELD – hold only. No drag-to-grab.
        const sh = this.refs.shield;
        sh.addEventListener('pointerdown', (e) => {
            e.preventDefault(); e.stopPropagation();
            sh.classList.add('down');
            virtual.shield = true; virtual.left = virtual.right = false; this.dirX = 0;
            this.api.heldChanged();
        });
        const shEnd = () => { sh.classList.remove('down'); virtual.shield = false; this.api.heldChanged(); };
        sh.addEventListener('pointerup', shEnd); sh.addEventListener('pointercancel', shEnd); sh.addEventListener('pointerleave', shEnd);

        // SEPARATE GRAB button – drag to aim, release fires, snaps back
        const gr = this.refs.grab;
        let gg = null;
        gr.addEventListener('pointerdown', (e) => {
            if (gg) return;
            e.preventDefault(); e.stopPropagation();
            gr.setPointerCapture(e.pointerId);
            gg = { id: e.pointerId, sx: e.clientX, sy: e.clientY };
            gr.classList.add('down');
        });
        gr.addEventListener('pointermove', (e) => {
            if (!gg || e.pointerId !== gg.id) return;
            const dx = e.clientX - gg.sx, dy = e.clientY - gg.sy;
            const len = Math.hypot(dx, dy);
            const k = len > 48 ? 48 / len : 1;
            gr.style.transform = `translate(${dx * k}px, ${dy * k}px)`;
            if (len > 20) {
                const m = this.me();
                const mag = Math.hypot(dx, dy) || 1;
                mouse.worldX = m.x + (dx / mag) * 500;
                mouse.worldY = m.y + (dy / mag) * 500;
            }
        });
        const grEnd = (e) => {
            if (!gg || (e && e.pointerId !== gg.id)) return;
            const dx = (e ? e.clientX : gg.sx) - gg.sx;
            const dy = (e ? e.clientY : gg.sy) - gg.sy;
            const len = Math.hypot(dx, dy);
            gg = null;
            gr.classList.remove('down');
            gr.style.transform = '';
            if (len > 28) {
                const mag = len || 1;
                this.act('grab', 'NEUTRAL', [dx / mag, dy / mag]);
            } else {
                this.act('grab', 'NEUTRAL');
            }
        };
        gr.addEventListener('pointerup', grEnd); gr.addEventListener('pointercancel', grEnd);

        this.hud.addEventListener('touchmove', (e) => e.preventDefault(), { passive: false });
        this.hud.addEventListener('gesturestart', (e) => e.preventDefault());
    }
}
