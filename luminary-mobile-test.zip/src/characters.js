// Character roster for The Luminary
// Melees share hitboxes; only animations / specials / walk speed differ.

export const CHARACTERS = [
  {
    id: 'luminary',
    name: 'The Luminary',
    short: 'Default',
    color: '#22d3ee',
    superColor: '#a855f7',
    walkSpeed: 1.0,
    description: 'The original fighter. Balanced speed and power. Neutral is an around-the-world sword spin that launches only upward. Specials: Blink Slash, Rising Spiral, Suplex / Headbutt, and the charged Luminary Core orb.',
    playstyle: 'Balanced',
    meleeNotes: {
      neutral: 'Sword spin (around-the-world) – launches up only',
      side: 'Horizontal slash',
      up: 'Rising slash',
      down: 'Spike / down smash'
    },
    special: 'Directional F moves + chargeable Core orb'
  },
  {
    id: 'vesper',
    name: 'Vesper',
    short: 'Vesper',
    color: '#a78bfa',
    superColor: '#c084fc',
    walkSpeed: 1.18,
    description: 'Light and fast assassin. Uses spinning dagger flourishes. Excellent mobility and mix-ups. Shadow Step gives a short invincible blink that ends in a slash.',
    playstyle: 'Light / Fast',
    meleeNotes: {
      neutral: 'Spinning dagger flourish',
      side: 'Horizontal slash with afterimage',
      up: 'Rising corkscrew kick',
      down: 'Ground pound with dagger'
    },
    special: 'Shadow Step – invincible blink + slash on arrival'
  },
  {
    id: 'titan',
    name: 'Titan',
    short: 'Titan',
    color: '#f97316',
    superColor: '#fb923c',
    walkSpeed: 0.78,
    description: 'Heavy tank. Slow walk but huge presence. Fortress grants temporary super armor and can reflect small projectiles. Hard to launch, hits like a truck.',
    playstyle: 'Tank / Slow',
    meleeNotes: {
      neutral: 'Heavy overhead cleave (slower startup)',
      side: 'Wide horizontal hammer',
      up: 'Upward shoulder bash',
      down: 'Ground stomp shockwave'
    },
    special: 'Fortress – super armor + reflect small projectiles'
  },
  {
    id: 'nyx',
    name: 'Nyx',
    short: 'Nyx',
    color: '#38bdf8',
    superColor: '#7dd3fc',
    walkSpeed: 1.05,
    description: 'Elegant balanced sword fighter. Clean animations and a unique special: Lunar Bind throws a slow homing crescent that freezes the opponent on hit for a short time.',
    playstyle: 'Balanced',
    meleeNotes: {
      neutral: 'Elegant sword spin',
      side: 'Quick thrust',
      up: 'Rising spiral slash',
      down: 'Downward spiral spike'
    },
    special: 'Lunar Bind – homing crescent that freezes on hit (~0.6s)'
  },
  {
    id: 'bolt',
    name: 'Bolt',
    short: 'Bolt',
    color: '#facc15',
    superColor: '#fde047',
    walkSpeed: 1.25,
    description: 'Glass-cannon speedster. Extremely fast walk and dash. Overcharge empowers the next melee and leaves a static trail. High risk, high reward.',
    playstyle: 'Light / Very Fast',
    meleeNotes: {
      neutral: 'Electric punch flurry',
      side: 'Side dash punch',
      up: 'Vertical uppercut',
      down: 'Dive kick'
    },
    special: 'Overcharge – next melee does 1.5× and leaves a static trail'
  },
  {
    id: 'grove',
    name: 'Grove',
    short: 'Grove',
    color: '#4ade80',
    superColor: '#86efac',
    walkSpeed: 0.95,
    description: 'Nature-themed support/fighter hybrid. Can plant a Bloom seed that heals allies or damages foes after a short delay. Solid mid-range pressure.',
    playstyle: 'Balanced / Medium',
    meleeNotes: {
      neutral: 'Vine whip circle',
      side: 'Horizontal vine lash',
      up: 'Rising vine lift',
      down: 'Root slam'
    },
    special: 'Bloom – seed that heals self / damages foes after 2s'
  },
  {
    id: 'rook',
    name: 'Rook',
    short: 'Rook',
    color: '#94a3b8',
    superColor: '#cbd5e1',
    walkSpeed: 0.85,
    description: 'Defensive tank with a deployable Bastion wall that blocks projectiles and pushes opponents. Strong edge-guarding and stage control.',
    playstyle: 'Tank / Medium-Slow',
    meleeNotes: {
      neutral: 'Shield bash spin',
      side: 'Heavy shoulder charge',
      up: 'Upward shield upper',
      down: 'Shield slam spike'
    },
    special: 'Bastion – temporary wall that blocks projectiles and pushes foes'
  },
  {
    id: 'ember',
    name: 'Ember',
    short: 'Ember',
    color: '#ef4444',
    superColor: '#f87171',
    walkSpeed: 1.12,
    description: 'Aggressive fire fighter. Combos build an Ignite stack; the third hit causes burn DoT plus a small explosion. Fast and explosive when on a roll.',
    playstyle: 'Glass Cannon / Fast',
    meleeNotes: {
      neutral: 'Flame spin (around-the-world with fire)',
      side: 'Fire arc slash',
      up: 'Rising flame pillar',
      down: 'Downward meteor stomp'
    },
    special: 'Ignite – build burn stacks; 3rd hit explodes + DoT'
  }
];

export function getCharacter(id) {
  return CHARACTERS.find(c => c.id === id) || CHARACTERS[0];
}

export function getDefaultCharacterId() {
  try {
    return localStorage.getItem('luminary-char') || 'luminary';
  } catch {
    return 'luminary';
  }
}

export function setSelectedCharacter(id) {
  try {
    localStorage.setItem('luminary-char', id);
  } catch {}
}
