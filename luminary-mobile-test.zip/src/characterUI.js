// Character select panel – preview on the right, list on the left, descriptions.
import { CHARACTERS, getCharacter, getDefaultCharacterId, setSelectedCharacter } from './characters.js';

export class CharacterUI {
  constructor({ root, onSelect }) {
    this.onSelect = onSelect || (() => {});
    this.selected = getDefaultCharacterId();
    this.el = document.createElement('div');
    this.el.className = 'lm-modal lm-hidden';
    this.el.innerHTML = `
      <div class="lm-panel lm-char-panel" role="dialog" aria-label="Choose Character" style="max-width:920px;width:95%">
        <div class="lm-head">
          <h2>Choose Fighter</h2>
          <button class="lm-x" data-close aria-label="Close">✕</button>
        </div>
        <div class="lm-body lm-char-body" style="display:flex;gap:16px;min-height:380px">
          <div class="lm-char-list" data-list style="flex:0 0 240px;overflow-y:auto;max-height:420px"></div>
          <div class="lm-char-preview" data-preview style="flex:1;display:flex;flex-direction:column;gap:12px">
            <div data-preview-visual style="height:160px;border-radius:16px;background:linear-gradient(135deg,#0f172a,#1e293b);display:flex;align-items:center;justify-content:center;border:1px solid #334155;position:relative;overflow:hidden">
              <div data-preview-color style="width:72px;height:72px;border-radius:50%;box-shadow:0 0 40px currentColor"></div>
              <span data-preview-name style="position:absolute;bottom:12px;font-weight:800;letter-spacing:0.08em;text-transform:uppercase;font-size:18px"></span>
            </div>
            <div data-preview-desc style="font-size:13px;line-height:1.5;color:#cbd5e1;flex:1"></div>
            <div data-preview-meta style="font-size:12px;color:#94a3b8"></div>
            <button class="lm-btn" data-confirm style="align-self:flex-start;background:linear-gradient(90deg,#06b6d4,#3b82f6);color:#0f172a;font-weight:800;padding:10px 20px;border-radius:12px;border:none;cursor:pointer">Select Fighter</button>
          </div>
        </div>
      </div>`;
    root.appendChild(this.el);
    this.list = this.el.querySelector('[data-list]');
    this.previewColor = this.el.querySelector('[data-preview-color]');
    this.previewName = this.el.querySelector('[data-preview-name]');
    this.previewDesc = this.el.querySelector('[data-preview-desc]');
    this.previewMeta = this.el.querySelector('[data-preview-meta]');
    this.el.addEventListener('click', (e) => {
      if (e.target === this.el || e.target.closest('[data-close]')) this.hide();
      const row = e.target.closest('[data-id]');
      if (row) { this.selected = row.dataset.id; this.renderList(); this.renderPreview(); }
      if (e.target.closest('[data-confirm]')) {
        setSelectedCharacter(this.selected);
        this.onSelect(this.selected);
        this.hide();
      }
    });
  }

  open(currentId) {
    this.selected = currentId || getDefaultCharacterId();
    this.renderList();
    this.renderPreview();
    this.el.classList.remove('lm-hidden');
  }

  hide() { this.el.classList.add('lm-hidden'); }
  isOpen() { return !this.el.classList.contains('lm-hidden'); }

  renderList() {
    this.list.innerHTML = CHARACTERS.map(c => `
      <button data-id="${c.id}" class="lm-char-row ${c.id === this.selected ? 'sel' : ''}"
        style="display:flex;align-items:center;gap:10px;width:100%;text-align:left;padding:10px 12px;margin-bottom:6px;border-radius:12px;border:1px solid ${c.id === this.selected ? c.color : '#334155'};background:${c.id === this.selected ? 'rgba(255,255,255,0.06)' : 'transparent'};cursor:pointer;color:inherit">
        <span style="width:14px;height:14px;border-radius:50%;background:${c.color};box-shadow:0 0 10px ${c.color};flex-shrink:0"></span>
        <span style="font-weight:700;font-size:13px">${c.name}</span>
        <span style="margin-left:auto;font-size:10px;opacity:0.6;text-transform:uppercase">${c.playstyle.split('/')[0].trim()}</span>
      </button>`).join('');
  }

  renderPreview() {
    const c = getCharacter(this.selected);
    this.previewColor.style.background = c.color;
    this.previewColor.style.color = c.color;
    this.previewName.textContent = c.name;
    this.previewName.style.color = c.color;
    this.previewDesc.innerHTML = `<strong style="color:#e2e8f0">${c.name}</strong> — ${c.description}`;
    this.previewMeta.innerHTML = `
      <div><b>Playstyle:</b> ${c.playstyle} · <b>Walk:</b> ${c.walkSpeed.toFixed(2)}×</div>
      <div style="margin-top:6px"><b>Neutral:</b> ${c.meleeNotes.neutral}</div>
      <div><b>Special:</b> ${c.special}</div>`;
  }
}
